import React from 'react'

function AddWheel() {
  return (
    <div>AddWheel Content</div>
  )
}

export default AddWheel