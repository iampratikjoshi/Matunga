import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { IoCloudUploadOutline } from "react-icons/io5";
import { useDropzone } from "react-dropzone";
import "../../resources/LHB/NewPreInspectionForm/newpreinspectionform.css";

function BDAndCoachDetails({
  formDataScheduleEMU,
  setFormDataScheduleEMU,
  onInputChange,
  onNextStep,
  onResetStep,
}) {
  const [BDDefect, setBDDefect] = useState(formDataScheduleEMU.BDDefect); // State for BDDefect dropdown
  const [OtherBDDefect, setOtherBDDefect] = useState(""); // State for other BDDefect input

  const [BDMakeIN, setBDMakeIN] = useState(formDataScheduleEMU.BDMakeIN); // State for CTRBMakeB dropdown
  const [OtherBDMakeIN, setOtherBDMakeIN] = useState(""); // State for other CTRBMakeB input

  const [fileName, setFileName] = useState("No file chosen");
  const [preview, setPreview] = useState(null);
  const [errors, setErrors] = useState({}); // State for validation errors
  const [file, setFile] = useState(null); // Single file state
  const [isBackNavigation, setIsBackNavigation] = useState(false); // State to track back navigation
  const { getRootProps, getInputProps } = useDropzone({
    accept: "image/*", // Accept only image files
    multiple: false, // Allow only one file
    onDrop: (acceptedFiles) => {
      const file = acceptedFiles[0];

      // Manually validate if the file is an image
      if (file && file.type.startsWith("image/")) {
        setFile(file); // Set the single file to state
      }
    },
  });

  const handleBDDefectChange = (event) => {
    const selectedRemark = event.target.value;
    setBDDefect(selectedRemark);

    // If "Others" is selected, we use OtherRemark, otherwise, we set Remark
    if (selectedRemark !== "others") {
      // console.log(selectedRemark);
      // console.log(BDDefect);

      setFormDataScheduleEMU((prevData) => ({
        ...prevData,
        BDDefect: selectedRemark,
        // OtherRemark: "", // Clear out the OtherRemark field
      }));
    } else {
      setFormDataScheduleEMU((prevData) => ({
        ...prevData,
        BDDefect: "", // Clear out the Remark field
      }));
    }
  };

  const handleOtherBDDefectChange = (event) => {
    const { value } = event.target;
    setOtherBDDefect(value);
    setFormDataScheduleEMU((prevData) => ({
      ...prevData,
      BDDefect: value,
    }));

    console.log(formDataScheduleEMU.BDDefect);
  };

  const handleBDMakeINChange = (event) => {
    const selectedRemark = event.target.value;
    setBDMakeIN(selectedRemark);

    // If "Others" is selected, we use OtherRemark, otherwise, we set Remark
    if (selectedRemark !== "others") {
      // console.log(selectedRemark);
      // console.log(BDMakeIN);

      setFormDataScheduleEMU((prevData) => ({
        ...prevData,
        BDMakeIN: selectedRemark,
        // OtherRemark: "", // Clear out the OtherRemark field
      }));
    } else {
      setFormDataScheduleEMU((prevData) => ({
        ...prevData,
        BDMakeIN: "", // Clear out the Remark field
      }));
    }
  };

  const handleOtherBDMakeINChange = (event) => {
    const { value } = event.target;
    setOtherBDMakeIN(value);
    setFormDataScheduleEMU((prevData) => ({
      ...prevData,
      BDMakeIN: value,
    }));

    console.log(formDataScheduleEMU.BDMakeIN);
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    onInputChange(name, value);
    console.log(formDataScheduleEMU);
  };

  const handleCancel = () => {
    setFormDataScheduleEMU((prevFormData) => ({
      ...Object.keys(prevFormData).reduce((acc, key) => {
        acc[key] = null;
        return acc;
      }, {}),
      createdBy: "ADMIN",
      SectionId: 1,
      DepartmentId: 2,
      WheeltypeId: 4,
    }));
    onResetStep();
    navigate("/emuschedulepreinspectionform/details");
  };

  const handleBack = () => {
    setIsBackNavigation(true); // Set flag when navigating back
    navigate("/emuschedulepreinspectionform/details");
  };

  const navigate = useNavigate();

  const saveandcontinue = () => {
    if (!isBackNavigation) {
      onNextStep();
      setIsBackNavigation(false);
    }
    // setIsBackNavigation(false); // Reset flag after proceeding to next step
    navigate("/emuschedulepreinspectionform/ctrba_details");
  };

  return (
    <div className="componentPreInspection">
      <h2
        style={{
          textAlign: "center",
          backgroundColor: "black",
          color: "white",
          opacity: 1,
        }}
      >
        EMU PRE INSPECTION FORM
      </h2>
      <h2>BD And COACH Details for EMU PRE Inspection Form</h2>

      <div className="page-borderPreInspection">
        <div className="page-contentLHB">
          <div className="wheel-page-main-PreInspection-content">
            <div className="PreInspectionrow-1">
              <div>
                <label>BD Make:</label>
                {/* <input
                  type="text"
                  name="BDMakeIN"
                  value={formDataScheduleEMU.BDMakeIN}
                  onChange={handleChange}
                  placeholder="Enter BD Make"
                /> */}
                <select
                  name="BDMakeIN"
                  value={BDMakeIN}
                  onChange={handleBDMakeINChange}
                >
                  <option value="">Choose BD Make</option>
                  <option value="Knorr">Knorr</option>
                  <option value="Faiveley">Faiveley</option>
                  <option value="JWL">JWL</option>
                  <option value="Pioneer">Pioneer</option>
                  <option value="others">Others</option>
                </select>
              </div>
              {BDMakeIN === "others" && (
                <div>
                  <label>Enter Specific BD Make:</label>
                  <input
                    type="text"
                    name="OtherRemark"
                    value={OtherBDMakeIN}
                    onChange={handleOtherBDMakeINChange}
                    placeholder="Enter Specific BD Make"
                  // Adjust spacing
                  />
                </div>
              )}
              <div>
                <label>Coach No.:</label>
                <input
                  type="text"
                  name="CoachNumber"
                  value={formDataScheduleEMU.CoachNumber}
                  onChange={handleChange}
                  placeholder="Enter Coach No."
                />
              </div>
            </div>
            <div className="PreInspectionrow-2">
              <div>
                <label>BD Thickness A:</label>
                <input
                  type="text"
                  name="BDThicknessA"
                  value={formDataScheduleEMU.BDThicknessA}
                  onChange={handleChange}
                  placeholder="Enter BD Thickness A"
                />
              </div>
              <div>
                <label>BD Thickness B:</label>
                <input
                  type="text"
                  name="BDThicknessB"
                  value={formDataScheduleEMU.BDThicknessB}
                  onChange={handleChange}
                  placeholder="Enter BD Thickness B"
                />
              </div>
            </div>

            <div className="PreInspectionrow-3">
              <div>
                <label>BD Defect:</label>
                <select
                  name="BDDefect"
                  value={BDDefect}
                  onChange={handleBDDefectChange}
                  required
                >
                  <option value="">Choose BD Defect</option>
                  <option value="ThermalCrack">Thermal Crack</option>
                  <option value="IncipientCrack">Incipient Crack</option>
                  <option value="ConcaveWear/HollowWear">
                    Concave Wear/ Hollow Wear
                  </option>
                  <option value="FinsBroken">Fins Broken</option>
                  <option value="EdgeBroken">Edge Broken</option>
                  <option value="Scoring">Scoring</option>
                  <option value="SharpEdge">Sharp Edge</option>
                  <option value="BlackSpot">Black Spot</option>
                  <option value="HairLineCrack">Hair Line Crack</option>
                  <option value="others">Others</option>
                  {/* <input
                  type="text"
                  name="BDDefect"
                  value={formDataScheduleEMU.BDDefect}
                  onChange={handleChange}
                  placeholder="Enter BD Defect"
                /> */}
                </select>
              </div>
              {BDDefect === "others" && (
                <div>
                  <label>Enter Specific BD Defect:</label>
                  <input
                    type="text"
                    name="OtherRemark"
                    value={OtherBDDefect}
                    onChange={handleOtherBDDefectChange}
                    placeholder="Enter Specific BD Defect"
                  // Adjust spacing
                  />
                </div>
              )}
            </div>
            <div className="PreInspectionrow-3">
              <div></div>
              <div></div>
            </div>

            <div className="btn-containerPreInspection">
              <button onClick={saveandcontinue}>Save & Continue</button>
              <button onClick={handleBack}>Back</button>
              <button className="red_btn" onClick={handleCancel}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BDAndCoachDetails;
